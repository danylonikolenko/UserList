<?php
require "database.php";

$name_red = $_POST['name_wo_red'];
$po_red = $_POST['posadaRed'];
$dep_red = $_POST['departRed'];
$di_red = $_POST['divisRed'];
$phone_red = $_POST['phone_red'];
$room_red = $_POST['room_red'];
$idUser = $_POST['data'];
 $idhide = $_POST['hideId'];

$di_red = $di_red ? $di_red :  '0' ;

$k = "UPDATE `workers` SET `name_wo`= '" .$name_red. "' ,`posada`=".$po_red.",`phone`='".$phone_red."',`room`='".$room_red."',`depart`=".$dep_red.",`divis`=".$di_red." WHERE `id_wo` = ".$idhide." ";

if(isset($_POST['redact'])){

   $db->query($k);
 //Header('Location:index.php');
}