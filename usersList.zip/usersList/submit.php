<?php
require "database.php";
$name_wo = $_POST['name_wo'];
$phone = $_POST['phone'];
$room= $_POST['room'];
$depart = $_POST['depart'];
$posada = $_POST["posada"];
$divis = $_POST["divis"];
$divisDep = $_POST['departDivis'];
$del_wo = $_POST['del_wo'];
//print_r($del_wo);


$divis = $divis ? $divis :  '0' ;

$s="INSERT INTO $db_workers(`name_wo`, `phone`, `room`, `depart`, `divis`, `posada`) VALUES ('".$name_wo."','".$phone."','".$room."',$depart,$divis,$posada)";
//return print_r($s);
if (isset($_POST['addWorker'])){

   $db->query($s);
    Header('Location:index.php');
}

$q="DELETE FROM $db_workers WHERE '".$_POST['del_id']."' IN(`id_wo`)" ;

if (isset($_POST['deleteWo'])){
    $db->query($q);
    Header('Location:index.php');
}





$s1="INSERT INTO `dep`(`name_de`) VALUES ('".$_POST['new_dep']."')";

if (isset($_POST['addDep'])){

    $db->query($s1);
    Header('Location:index.php');
}

$s12="INSERT INTO `division`(`name_di`,`divis_dep`) VALUES ('".$_POST['new_div']."' , $divisDep)";
    if (isset($_POST['addDiv'])){

    $db->query($s12);
    Header('Location:index.php');
}