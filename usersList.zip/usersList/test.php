<?php
require "database.php";
require_once "PHPExcel-1.8/Classes/PHPExcel.php";

$sqlExcel = "
SELECT  * FROM `workers` 
  join`dep` on `dep`.id_dep = `workers`.depart
           join `position`  on `position`.id = `workers`.posada
         
           left join `division`  on `division`.id_di = `workers`.divis
           
            ORDER BY `dep`.id_dep, `division`.id_di, `position`.id
";
if (isset($_POST['exportExcel'])) {
    $rEx = mysqli_query($mysqli, $sqlExcel);
    if (mysqli_num_rows($rEx) > 0) {
        $z .= '<table style="border: 1px gray solid " >
    <thead class="">
    <tr style="border: 1px gray solid ">

        <th  scope="col">Найменування посади</th>
        <th style="text-align: center" scope="col">ПІБ</th>
        <th style="text-align: center" scope="col">Тел. номер</br>(594-XX-XX)</th>
        <th style="text-align: center" scope="col">Кімната</th>

    </tr>

    ';


        $result = $mysqli->query($sql);
        $result2 = $mysqli->query($sql);

        $o = [];
        $id_di = [];
        foreach ($result as $e) {
            array_push($o, $e);
            array_push($id_di, $e['id_di']);
            $ar_dii = array_unique($id_di);
        }

        $o = 0;
        foreach ($ar_dii as $divs) {
            if ($divs != 0) {
                $uni_di[$o] = $divs;
                $o++;
            }
        }

        $d = [];
        $id_de= [];
        foreach ($result as $r) {
            array_push($d, $r);
            array_push($id_de, $r['id_dep']);
            $ar_de = array_unique($id_de);
        }

        $d = 0;
        foreach ($ar_de as $dep) {
            if ($dep != 0) {
                $uni_de[$d] = $dep;
                $d++;
            }
        }


        $out_arr = [];
        $out_arrD = [];
                         while ($row = mysqli_fetch_array($rEx)) {
                             if ($row['id_dep'] != 0 && in_array($row['id_dep'], $uni_de, true) && !in_array($row['id_dep'], $out_arrD, true)) {
                                 array_push($out_arrD, $row['id_dep']);

                                 $z .= "<tr >
                                    <td colspan='4' style='text-align: center;font-weight: bold; color:rebeccapurple' class='diname'>" . $row['name_de'] . "  </br>
                                       <input class='hideDi' type='hidden'  value='" . $row['id_dep'] . "'>
                                    </td></tr>";

                             }


                            if ($row['id_di'] != 0 && in_array($row['id_di'], $uni_di, true) && !in_array($row['id_di'], $out_arr, true)) {
                                array_push($out_arr, $row['id_di']);

                                $z .= "<tr >
                                    <td colspan='4' style='text-align: left;font-weight: bold; color:coral' class='diname'>" . $row['name_di'] . "  </br>
                                       <input class='hideDi' type='hidden'  value='" . $row['id_di'] . "'>
                                    </td></tr>";

                            }


                            $z .= "<tr style=\"border: 1px gray ridge \">
 
                                                                <td class='poname'>" . $row['name_po'] . "</td>
                                                             
                                                                <td class='woname'>" . $row['name_wo'] . "</td>
                                                               
                                                                <td class='pname'>" . $row['phone'] . "</td>
                                                                <td class='rname' style='text-align: right'>"  . $row['room'] . " </td>

                                                       

                                                                </tr>

                                                            ";

                    }






        $z .= '</table';

        header("Content-Type: application/xls");
        header("Content-Disposition: attachment; filename=export.xls");
        echo($z) ;
    }
}
