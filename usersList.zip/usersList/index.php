<?php
require"database.php";
require "submit.php";
require "red.php";
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>userlist</title>


    <link rel="stylesheet" href="style.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/css/mdb.min.css" rel="stylesheet">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


</head>
<body>
<!--Модалк ДЕПАРТАМЕНТ-->
<div class="modalFormDep" id="modalDep">
    <form method="POST" action="">
        <div class="formDep-content">
            <span class="closeDep" style="position: absolute; top: 0; right: 0; margin: 8px;">&times;</span>
            <p style="text-align: center"><h3 >Додати новий департамент</h3></p></br>
            <input name="new_dep" placeholder="Назва департаменту" style="width: 90%;padding:10px;text-align: center; margin-left: auto;margin-right: auto; border: none; border-bottom: 1px rgba(0,0,0,0.35) solid; background-color: whitesmoke">
            <input name="addDep" class="sub" type="submit" value="Зберегти" style="margin-bottom: 15px">
        </div>
    </form>
</div>
<!--Модалк ОТДЕЛ-->

<div class="modalFormDiv" id="modalDiv">
    <form method="POST" action="">
        <div class="formDiv-content">
            <span class="closeDiv" style="position: absolute; top: 0; right: 0; margin: 8px;">&times;</span>
            <p style="text-align: center; margin-bottom: 20px;"><h3 >Додати новий відділ</h3></p></br>
            <input name="new_div" placeholder="Назва відділ" style="width: 90%;padding:10px;text-align: center; margin-left: auto;margin-right: auto; border: none; border-bottom: 1px rgba(0,0,0,0.35) solid; background-color: whitesmoke">
            <select class="browser-default custom-select" name="departDivis" style="margin-bottom: 10px">

                <option>ДЕПАРТАМЕНТ ВІДДІЛУ</option>
                <?php
                $sqlRedDep= "SELECT * FROM `dep` ";
                $resultRedPo= $mysqli->query($sqlRedDep);
                foreach ($resultRedPo as $key=>$item2) {
                    $index = $key+1;
                    echo "<option   value='" . $index . "' >" . $item2['name_de'] . "</option> ";
                }
                ?>



            </select>
            <input name="addDiv" class="sub" type="submit" value="Зберегти" style="margin-bottom: 15px">
        </div>
    </form>
</div>

<!--Модалка редактирования-->

<div class="modalFormRed" id="modalRed" >
        <div class="formRed-content">
            <form id="form_danila" method="POST" action="">
            <span class="closeRed" style="position: absolute; top: 0; right: 0; margin: 8px;">&times;</span>
            <p style="text-align: center;font-size: 24px">Редагувати данні</p></br>
            <table class="table">
                <tr>
                    <th scope="col">Департамент</th>
                    <th scope="col">Структурний підрозділ</th>
                    <th scope="col">Посада</th>
                    <th scope="col">ПІБ</th>
                    <th scope="col">Тел. номер</br>(594-XX-XX)</th>
                    <th scope="col">Кімната</th>
                    <th scope="col">Зберегти данні</th>
                </tr>
                <tr>
                    <td>
                        <select class="browser-default custom-select" name="departRed" style="margin-bottom: 10px">
                            <option class="val-dep" ></option>

                            <?php
                            $sqlRedDep= "SELECT * FROM `dep` ";
                            $resultRedPo= $mysqli->query($sqlRedDep);
                            foreach ($resultRedPo as $key=>$item2) {
                                $index = $key+1;
                                echo "<option   value='".$index."' >" . $item2['name_de'] . "</option> ";
                            }
                            ?>



                        </select>
                    </td>
                    <td>

                        <select  class="browser-default custom-select" name="divisRed" style="margin-bottom: 10px">
                            <option class="val-div" selected = "selected"></option>

<!--                            --><?php
//                            $sqlRedDiv = "SELECT * FROM `division`";
//                            $resultRedDiv = $mysqli->query($sqlRedDiv);
//                            foreach ($resultRedDiv as $key=>$item2) {
//                                $index = $key;
//                                echo "<option  value='".$index."' >" . $item2['name_di'] . "</option> ";
//                            }
//                            ?>
                        </select>

                        </td>

                    <td>
                        <select  class="browser-default custom-select" name="posadaRed" style="margin-bottom: 10px">
                            <option class="val-pos" selected = "selected"></option>
                            <?php
                            $sqlRedPo = "SELECT * FROM `position`";
                            $resultRedPo = $mysqli->query($sqlRedPo);
                            foreach ($resultRedPo as $key=>$item2) {
                                $index = $key+1;
                                echo "<option  value='".$index."' >" . $item2['name_po'] . "</option> ";
                            }
                            ?>
                        </select>
                    </td>
                    <td  scope="col"><input class="val-wo" name="name_wo_red"  style="border: 1px solid rgba(0,0,0,0.32); padding: 10px"></th>
                    <td  scope="col"><input class="val-phone" name="phone_red" style="border: 1px solid rgba(0,0,0,0.32); padding: 10px"></td>
                    <td  scope="col"><input class="val-room" name="room_red"style="border: 1px solid rgba(0,0,0,0.32); padding: 10px"></td>
                    <input name="hideId" type="hidden" class="hideId-modal"  value="">
                    <td  scope="col"><input name="redact" id="redact" type="submit" value="Зберегти"></td>
                </tr>
                </form>
                </tbody>
            </table>
        </div>
</div>

</div>

<!--Модалка НОВЫЙ РАБотник-->

<div class="modalForm" id="modal">
    <form method="POST" action="">
        <div class="form-content"  >
            <span class="close" style="position: absolute; top: 0; right: 0; margin: 8px;">&times;</span>
            <p style="text-align: center"><h3 >Додати працівника</h3></p></br>
            <input name="name_wo" placeholder="ПІБ" style="width: 70%;padding:10px;text-align: center; margin-left: auto;margin-right: auto; border: none; border-bottom: 1px rgba(0,0,0,0.35) solid; background-color: whitesmoke">
            <input name="room" placeholder="Кімната" style="width: 70%; margin-left: auto;text-align: center;margin-right: auto;margin-top: 20px; border: none; border-bottom: 1px rgba(0,0,0,0.35) solid; background-color: whitesmoke">
            <input name="phone" placeholder="Номер т\ф" style="width: 70%; margin-left: auto;text-align: center;margin-right: auto;margin-top: 20px;margin-bottom: 20px; border: none; border-bottom: 1px rgba(0,0,0,0.35) solid; background-color: whitesmoke">
            <select id="depSelect" class="browser-default custom-select" name="depart"  style="margin-bottom: 10px">
                <option>ДЕПАРТАМЕНТ:</option>

                <?php
                $sql1 = "SELECT * FROM `dep` ";
                $result4 = $mysqli->query($sql1);
                foreach ($result4 as $key=>$item2) {
                    $index = $key+1;
                    echo "<option value='".$index."' >" . $item2['name_de'] . "</option> ";
                }

                ?>
<!--                <script>-->
<!---->
<!--                    $( "#depSelect" ).change(function() {-->
<!---->
<!--                        var depSel= $("#depSelect").val();-->
<!---->
<!--                        $.ajax({-->
<!--                            url: "depDiv.php",-->
<!--                            method: 'post',-->
<!--                            data: {content:depSel}-->
<!--                        }).done(function(a) {-->
<!--                            // alert(a);-->
<!--                        });-->
<!--                    });-->
<!---->
<!--                </script>-->

            </select>
            <select id="divSelect" class="browser-default custom-select" name="divis" style="margin-bottom: 10px">
                <option>СТРУКТУРНИЙ ПІДРОЗДІЛ:</option>
                <?php
                $sql5 = "SELECT * FROM `division`";
//                $sqlDivDep = "SELECT * FROM `division`di
//                             join `dep` de on de.id_dep = di.divis_dep
//                             WHERE di.divis_dep = '$cont'";

                $result411 = $mysqli->query($sql5);
//                $result41 = $mysqli->query($sql5);
//                foreach ($result41 as $key=>$item2) {
//                    $index = $key;
//                    if($item2['name_di']==null){
//                    echo "<option value='".$index."' >" . $item2['name_di'] . "</option> ";
//                    }
//                }

//                foreach ($result411 as $key=>$item2) {
//                    $index = $key;
//
//                    echo "<option value='".$index."' >" . $item2['name_di'] . "</option> ";
//                }
                ?>
                <script>


                    $( '[name = "depart"]' ).change(function() {

                        let divs_dep = $($('[name="depart"]')[0]).val();
                        $.ajax({

                            type: "get",
                            url: 'newWorkers.php',
                            data : {divs_dep: divs_dep},
                            success: function(data)
                            {
                                $('[name="divis"]').empty();
                                let divis1 = JSON.parse(data);

                                $('[name="divis"]').append('<option value="'+0+'"></option>');
                                $.each(divis1, function(id, divis1) {

                                    $('[name="divis"]').append('<option value="'+id+'">' + divis1 + '</option>');


                                });

                            }
                        });

                    });

                </script>
                   </select>
            <select class="browser-default custom-select" name="posada" style="margin-bottom: 10px">
                <option>ПОСАДА:</option>
                <?php
                $sql4 = "SELECT * FROM `position` ";
                print_r($sql4);
                $result42 = $mysqli->query($sql4);
                foreach ($result42 as $key=>$item2) {
                                    $index = $key+1;
                                   echo "<option value='".$index."' >" . $item2['name_po'] . "</option> ";
                              }
                ?>
            </select>

            <input name="addWorker"  class="sub" type="submit" value="Зберегти" style="margin-bottom: 15px">
        </div>
    </form>
</div>


<!--Шапка страницы-->


<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <div class="navbar-nav">

            <div class="btn-group">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Функції
                </button>
                <div class="dropdown-menu">
                    <a  id="openmodal" class="dropdown-item" href="#">Додати працівника</a>
                    <a id="openmodalDep" class="dropdown-item" href="#">Додати департамент</a>
                    <a id="openmodalDiv" class="dropdown-item" href="#">Додати відділ</a>
                    <div class="dropdown-divider"></div>
                    <form method="POST"  style="width: 90%" action="test.php">
                        <input  class="dropdown-item" style="color: green; font-weight: bold;" name="exportExcel" type="submit" href="#" value="Загрузка в Excel">
                    </form>




        </div>

            </div>

        </div>

    </div>
</nav>


<!--Шапка таблицы-->

    <div class="content" style="width: 80%; margin-left: auto;margin-right: auto;margin-top: 5px">

<table class="table table-bordered table-dark">
    <thead class="">
    <tr>

        <th  scope="col">Найменування посади</th>
        <th style="text-align: center" scope="col">ПІБ</th>
        <th style="text-align: center" scope="col">Тел. номер</br>(594-XX-XX)</th>
        <th style="text-align: center" scope="col">Кімната</th>
        <td style="text-align: center" scope="col">Редагувати</br> данні</td>
        <td style="text-align: center" scope="col">Видалити</br>  працівника</td>
    </tr>

    <tbody>
    <!--Вывод таблицы-->

    <?php

        $result = $mysqli->query($sql);
        $result2 = $mysqli->query($sql);

        $o = [];
        $id_di = [];
    foreach ($result as $e) {
        array_push($o,$e);
        array_push($id_di,$e['id_di']);
        $ar_dii = array_unique($id_di);
    }

    $o = 0;
    foreach($ar_dii as $divs) {
        if($divs != 0) {
            $uni_di[$o] = $divs;
            $o++;
        }
    }

//    $resultDiv= $mysqli->query($sqlDiv);
        $i = 0;
        $ar = [];
        $ar2 = [];
        $ar3 = array();
        $ar_dep = [];
            foreach ($result as $iyy) {
                array_push($ar,$iyy);
                array_push($ar2,$iyy['name_de']);
                $ar_dep = array_unique($ar2);
            }

            foreach($ar_dep as $item) {
                $ar3[$i] = $item;
                    $i++;
            }

                 $y = 0;
                $tab = [];
                $tab2 = [];
                $tab3 = [];
                $tab_di = [];
                    foreach ($result as $iii) {
                        array_push($tab,$iii);
                        array_push($tab2,$iii['name_di']);
                        $ar_di = array_unique($tab2);
                    }

                    foreach($ar_di as $divs) {
                        $tab3[$y] = $divs;
                            $y++;
                    }

        foreach ($ar3 as $key=>$item2) {


          echo " <tr>
                          <th class='dep_title' style='text-align: center; color: sandybrown; font-weight: normal font-size: 18px' colspan='6'>" . $ar3[$key] . "</th>
                           </tr> ";

                     $out_arr = [];
                     foreach ($result as $iyy) {

                         if ($iyy['name_de'] == $ar3[$key]) {


                             if ($iyy['id_di'] != 0 && in_array($iyy['id_di'], $uni_di, true) && !in_array($iyy['id_di'], $out_arr, true)) {
                                 array_push($out_arr, $iyy['id_di']);
                                 echo "<tr>
                                    <td colspan='6' style='text-align: left;font-weight: bold; color:coral' class='diname'>" . $iyy['name_di'] . "  </br>
                                       <input class='hideDi' type='hidden'  value='" . $iyy['id_di'] . "'>
                                    </td></tr>";
                             }

/*
                                                                <td class='diname'>" . $iyy['name_di'] . "  </br>
                                                                 <input class='hideDi' type='hidden'  value='" . $iyy['id_di'] . "'></td>*/
                             echo "<tr>
 
                                                                <td class='poname'>" . $iyy['name_po'] . "</br>
                                                                 <input class='hidePo' type='hidden'  value='" . $iyy['id'] . "'></td>
                                                                </td>
                                                                <td class='woname'>" . $iyy['name_wo'] . "</br>
                                                                </td>
                                                                <th  style='display: none'>" . $iyy['id_wo'] . "</th>
                                                                <td class='pname'>" . $iyy['phone'] . "</br></td></td>
                                                                <td class='rname'>" . $iyy['room'] . "</br>
                                                                 <input class='hideId' type='hidden' value='" . $iyy['id_wo'] . "'>
                                                                 <input class='hideDep' type='hidden'  value='" . $iyy['id_dep'] . "'>
                                                                 <input class='hideDepText'  type='hidden' value='" . $ar3[$key] . "'>
                                                                 <input class='diname' type='hidden' value='" . $iyy['name_di'] . "'> 
                                                                 <input class='hideDi' type='hidden'  value='" . $iyy['id_di'] . "'>

                                                                </td>

                                                                 <td><input class='btnWr'  type='submit'  name='rewrite' value='Редагувати'/></td>


                                                                <form method='POST' action=''>
                                                                <input  name = 'del_id' type='hidden' value='" . $iyy['id_wo'] . "'>
                                                                <td><input class='btnDel' type='submit'  name='deleteWo'   value='Видалити'/></td>
                                                                </form>

                                                                </tr>

                                                            ";

                         }
                     }
        }

        ?>
</table>




<script>
    function changeDiv(){
        let divis_dep = $($('[name="departRed"]')[0]).val();

        $.ajax({

            type: "get",
            url: 'department.php',
            data : {divis_dep: divis_dep},
            success: function(data)
            {
                let divises = JSON.parse(data);

                $('[name="divisRed"]').empty();
                $('[name="divisRed"]').append('<option value="'+0+'"></option>');
                $.each(divises, function(id, divise) {
                    $('[name="divisRed"]').append('<option value="'+id+'">' + divise + '</option>');


                });

                // $('[name="divisRed"]')
            }
        });
    }

    // Открытие\закрытие модалок
    var modal = document.getElementById('myModal');
    var span = document.getElementsByClassName("close")[0];
    //span - значёк крестик
    $('#openmodal').click(function(){
        $("#modal").show();


    });
    span.onclick = function () {
        $("#modal").hide();
    };
    window.onclick = function (event) {
        if(event.target == modal){
            modal.style.display = "none";
        }
    };
    var modalDep = document.getElementById('myModalDep');
    var spanDep = document.getElementsByClassName("closeDep")[0];
    $('#openmodalDep').click(function(){
        $("#modalDep").show();

    });
    spanDep.onclick = function () {
        $("#modalDep").hide();
    };
    window.onclick = function (event) {
        if(event.target == modalDep){
            modalDep.style.display = "none";
        }
    };
    var modalDiv = document.getElementById('myModalDiv');
    var spanDiv = document.getElementsByClassName("closeDiv")[0];
    $('#openmodalDiv').click(function(){
        $("#modalDiv").show();

    });
    spanDiv.onclick = function () {
        $("#modalDiv").hide();
    };
    window.onclick = function (event) {
        if(event.target == modalDep){
            modalDiv.style.display = "none";
        }
    };


//Модалка редактирования
    $(document).ready(function() {


    var spanRed = document.getElementsByClassName("closeRed")[0];
    $('.btnWr').click(function(){
        //Заполнение текущего фио тлф комнаты в окне редактирования
        var woname = $(this).parent().parent().find(".woname").text().trim();
        var pname = $(this).parent().parent().find(".pname").text().trim();
        var rname = $(this).parent().parent().find(".rname").text().trim();
        $(".val-wo").val(woname);
        $(".val-phone").val(pname);
        $(".val-room").val(rname);

        //Заполнение текущего сектора в окне редактирования
        var diname= $(this).parent().parent().find("td").find(".diname").val();
        var dinameId= $(this).parent().parent().find("td").find(".hideDi").val();
        $(".val-div").text(diname);
        $(".val-div").val(dinameId);

        //Заполнение текущей позиции в окне редактирования
        var poname = $(this).parent().parent().find(".poname").text();
        var ponameId = $(this).parent().parent().find(".hidePo").val();
        $(".val-pos").text(poname);
        $(".val-pos").val(ponameId);

        //Заполнение текущего департамента в окне редактирования
        var depname = $(this).parent().parent().find("td").find(".hideDep").val();
        var depnameText = $(this).parent().parent().find("td").find(".hideDepText").val();
        $(".val-dep").text(depnameText);
        $(".val-dep").val(depname);





    // ID выбранного работника
        var title = $(this).parent().parent().find("td").find(".hideId").val();

        $(".hideId-modal").val(title);
        changeDiv();

        $("#modalRed").show();


        });
        $('#redact').click(function(){

            var ser = $('#form_danila').serialize();
            //var id =  $(".hideId-modal").val();
            //alert(id);
            //return console.log(id);
            $.ajax({

                type: "POST",
                url: 'red.php',
                data : ser,
                success: function(ans)
                {
                   // alert(ans);
                }
            });
        });
        spanRed.onclick = function () {
            $("#modalRed").hide();
        };
        // window.onclick = function (event) {
        //     if(event.target == modalRed){
        //         modalRed.style.display = "none";
        //     }
        // };

        $('[name="departRed"]').change(function(elem) {
            changeDiv();



        });



    });






</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.7/js/mdb.min.js"></script>
</body>
</html>