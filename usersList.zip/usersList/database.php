<?php

$db_host = "localhost";
$db_user = "root"; // Логин БД
$db_password = "123"; // Пароль БД
$db_base = 'gp'; // Имя БД
$db_division = "division"; // Имя Таблицы БД
$db_dep = "dep"; // Имя Таблицы БД
$db_position = "position"; // Имя Таблицы БД
$db_workers= "workers"; // Имя Таблицы БД
$alterWorkers = "ALTER TABLE ".$db_workers." AUTO_INCREMENT=0";
$alterDivis = "ALTER TABLE ".$db_division." AUTO_INCREMENT=0";
$alterDep = "ALTER TABLE ".$db_dep." AUTO_INCREMENT=0";

$mysqli = mysqli_connect($db_host, $db_user, $db_password, $db_base);
$mysqli->query($alterDep);
$mysqli->query($alterWorkers);
$mysqli->query($alterDivis);


$sql = "SELECT * from ".$db_workers."  ww 
           join ".$db_dep." de on de.id_dep = ww.depart
           join ".$db_position." po on po.id = ww.posada
         
           left join ".$db_division." di on di.id_di = ww.divis
           
            ORDER BY de.id_dep, di.id_di, po.id
           ";
$sqlDiv = "SELECT * from ".$db_division." di
           join ".$db_dep." de on de.id_dep = di.divis_dep
           
       
           ";

$sqlDep = "SELECT * from ".$db_dep." de
         left join ".$db_division." di on di.divis_dep = de.id_dep
           ";
$db = mysqli_connect($db_host, $db_user, $db_password, $db_base);


