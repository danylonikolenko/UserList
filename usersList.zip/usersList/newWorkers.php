<?php
require "database.php";


$diviss = $_GET['divs_dep'];

$sqlNewDep= "SELECT * FROM `division` where divis_dep = " . $diviss;
$resultNewPo= $mysqli->query($sqlNewDep);

$result = [];

foreach ($resultNewPo as $key=>$item2) {
    $result[$item2['id_di']] = $item2['name_di'];
}

echo json_encode($result);

