<?php

require "database.php";


$divisDep = $_GET['divis_dep'];

$sqlRedDep= "SELECT * FROM `division` where divis_dep = " . $divisDep;
$resultRedPo= $mysqli->query($sqlRedDep);

$result = [];

foreach ($resultRedPo as $key=>$item2) {
    $result[$item2['id_di']] = $item2['name_di'];
}

echo json_encode($result);